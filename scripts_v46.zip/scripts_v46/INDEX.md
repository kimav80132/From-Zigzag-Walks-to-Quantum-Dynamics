# Scripts cited in "Three random particles, three wave equations" (v46) and in the Casimir document

120 scripts: 114 cited by the master, 6 cited only by the Casimir document. Each is a copy of the file in `scripts/`, unchanged.

Run one with `python3 <name>.py`. They need Python 3 with numpy, sympy and (some) scipy and mpmath.

| script | cited in |
|---|---|
| `B_to_A_dictionary.py` | III.8b, IV.7a |
| `III10_from_closure.py` | III.15a |
| `IV7_streaming_term_in_axis_variables.py` | IV.7 |
| `IV8_axis_fluid.py` | IV.8 |
| `audit_2026_11_09.py` | III.15d, III.15e, VI.4, VI.6 |
| `audit_gluing_draft_2026_11_09.py` | III.15d, VI.5 |
| `bell_from_scattering.py` | VI.3 |
| `bell_half_angle_calculation.py` | VI.3 |
| `bell_scattering_closed_form.py` | VI.3 |
| `bell_two_walkers_1plus1.py` | VI.3 |
| `bell_two_walkers_3plus1.py` | VI.3 |
| `bondi_and_the_two_senses.py` | III.15c |
| `boost_path_weight.py` | III.15d |
| `boosted_sheets_make_2plus1.py` | IV.4c |
| `boosting_the_rest_walker.py` | IV.5b |
| `boosts_streams.py` | IV.4d |
| `brownian_killed_4d.py` | III.16 |
| `carrier_and_field_action.py` | VI.2 |
| `carrier_sign_and_current.py` | VI.2 |
| `casimir_from_the_walk.py` | Casimir document |
| `charge_needs_doubling.py` | V.2 |
| `checkerboard_is_the_walk.py` | III.15a |
| `coin_casimir_from_the_no_flip_leg.py` | Casimir document |
| `complex_pairing_tool.py` | III.8b |
| `copy_is_return_leg.py` | III.8b, III.15a |
| `counting_in_spacetime.py` | III.15c |
| `current_is_the_weighted_twist.py` | III.11a |
| `detector_as_force.py` | III.15a, V.5 |
| `detectors_in_master_names.py` | III.8c, III.15e, III.15f, IV.5a, IV.5b, V.4 |
| `dirac3d_momentum.py` | IV.10 |
| `direction_weights_and_holonomy.py` | IV.2a |
| `eight_detectors.py` | IV.5a, IV.5b, V.4 |
| `eight_real_counters.py` | IV.5a |
| `elements_from_boosts.py` | IV.4d |
| `em_noise_factorization.py` | V.3 |
| `energy_vs_coin.py` | V.4 |
| `exclusion_as_volume.py` | VI.1 |
| `exclusion_must_be_basis_free.py` | VI.1 |
| `feynman_bottom_row.py` | IV.10 |
| `field_and_coin.py` | V.4 |
| `fock_space_from_the_walk.py` | VI.4 |
| `force_from_two_walks.py` | VI.2 |
| `force_is_a_turn_rate_gradient.py` | VI.2 |
| `four_lines_clock.py` | IV.4b, IV.7a |
| `frame_independence_forces_the_square.py` | III.15c |
| `gamma_uniqueness.py` | IV.4a |
| `gauge_detector.py` | V.5 |
| `gluing_sign_and_the_selected_reference.py` | VI.5 |
| `go_and_come_back_detector.py` | III.15a, V.5 |
| `half_rapidity_from_the_lines.py` | III.15c |
| `hole_is_opposite_loop.py` | VI.4, VI.6 |
| `hole_many_body_check.py` | VI.4, VI.6 |
| `imaginary_skew.py` | V.2 |
| `interaction_and_plates_checks.py` | III.8c, VI.2; Casimir document |
| `kick_integral_done_right.py` | IV.8 |
| `kinematic_collision_vs_fermion.py` | VI.1 |
| `loop_closure.py` | III.15a |
| `loop_reversal_and_the_sea.py` | VI.7 |
| `lorentz_force_turn_angle.py` | VI.2 |
| `lorentz_on_noise.py` | V.3 |
| `madelung_of_the_matrices.py` | IV.7a |
| `master_v33_new_text_checks.py` | III.15d, III.15e, VI.5, VI.6 |
| `modes_and_loops_are_poisson_partners.py` | Casimir document |
| `napkin_vacuum_estimate.py` | Next questions |
| `negative_pushes.py` | III.15a |
| `noise_matrix_dirac.py` | V.3 |
| `one_function_from_the_lines.py` | III.15 |
| `one_walker_one_frame.py` | IV.5b |
| `one_zigzag_one_cut_two_ribbons.py` | VI.1a |
| `ord_entwining_in_the_walk_1plus1.py` | III.8c |
| `pair_angle_is_a_connection.py` | VI.2 |
| `pauli_exclusion_every_state.py` | VI.1 |
| `pauli_from_one_process_per_point.py` | VI.1 |
| `pauli_test.py` | VI.1 |
| `perfect_absorber.py` | V.5 |
| `phase_is_the_angle_between_two_walks.py` | IV.5a |
| `plate_of_walkers_sum_and_difference.py` | VI.4; Casimir document |
| `plates_from_charged_walkers_checks.py` | Casimir document |
| `process_knobs.py` | V.1 |
| `quadratic_density_theorem.py` | III.15c |
| `radar_and_the_two_legs.py` | III.15c |
| `radial_test.py` | IV.2a |
| `real_dictionary.py` | III.15e |
| `relativistic_flip_rate.py` | V.4 |
| `return_as_pair_response_test.py` | VI.4 |
| `reversal_makes_the_return_leg.py` | III.15c |
| `review_v33_loop_sum_on_odd_ring.py` | VI.4 |
| `route_twin_loop.py` | III.15f |
| `runner_identities_proof.py` | IV.4c |
| `runner_section_3plus1.py` | IV.4c |
| `screen_of_detectors.py` | V.5 |
| `sea_in_coordinates_check.py` | III.15d, VI.5 |
| `second_copy_is_the_hilbert_transform.py` | III.8c |
| `skewed_covariance.py` | V.3 |
| `spin_current_by_direction.py` | IV.8 |
| `sqrt_k_as_an_eigenvalue_problem.py` | III.15c |
| `streams_section.py` | IV.4d |
| `symmetric_part_and_coincidence.py` | III.5a, III.15c |
| `three_coins_symbolic.py` | IV.10 |
| `tilt_is_a_boost.py` | III.15d |
| `tilted_matrix_noise.py` | V.3 |
| `transaction_lines.py` | III.15a |
| `true_spin.py` | IV.0, IV.7a, IV.8 |
| `turns_under_boost.py` | V.3 |
| `two_copy_walk_em.py` | III.8b, V.2 |
| `two_step_covariance.py` | IV.4d |
| `two_walker_plates_casimir_2plus1.py` | Casimir document |
| `universality_additivity.py` | IV.4d |
| `vacuum_picture.py` | VI.5 |
| `vacuum_polarization_sea_or_nothing.py` | VI.4 |
| `vacuum_snapshot_continuum_lines.py` | VI.5 |
| `vertex_rule_magnetism.py` | VI.2 |
| `vortex_core.py` | IV.8 |
| `vortex_worked.py` | IV.8 |
| `walk_1d_to_2d_by_runs.py` | IV.4c |
| `walker_at_rest_needs_the_pair.py` | IV.5a |
| `wall_twist_is_central_charge.py` | Casimir document |
| `which_reading_is_physical.py` | III.15b |
| `z_graph_and_closed_loop_are_exchange_partners.py` | VI.4 |
| `zigzag_signs_and_twin_checks.py` | III.8c, III.15a |
